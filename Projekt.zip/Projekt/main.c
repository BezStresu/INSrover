


	//#include "ADC.h"
	//#include "DAC.h"
	//#include "lcd1602.h"
	//#include "fsm.h"
	
	

int main(void) {
	
}
	